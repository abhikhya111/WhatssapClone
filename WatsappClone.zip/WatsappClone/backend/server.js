import express from 'express';
import mongoose from 'mongoose';
import Messages from './dbMessages.js';
import Rooms from './dbRooms.js';
import Pusher from 'pusher';
import cors from 'cors';

const app = express();
const PORT = 9000;

const pusher = new Pusher({
    appId: "1414591",
    key: "6fef707685d5c8bd3bde",
    secret: "b3bf4abbba00b8eb3cdf",
    cluster: "ap2",
    useTLS: true
  });
  

app.use(express.json());
app.use(cors());
const connection_url = 'mongodb+srv://abhikhya:ashi3666@crud.yjywtf4.mongodb.net/whatssapdb?retryWrites=true&w=majority';

mongoose.connect(connection_url,{
    useNewUrlParser: true,
    useUnifiedTopology: true
})

const db = mongoose.connection;

db.once('open', () => {
    console.log('MongoDb connected');

    const msgCollection = db.collection('messagecontents');
    const roomCollection = db.collection('roomcontents');

    const changeStream = msgCollection.watch();
    
    changeStream.on("change", (change) => {
        console.log('A change occured',change);

        if(change.operationType==='insert'){
            const messageDetails = change.fullDocument;
            pusher.trigger("messages","inserted", {
                name:messageDetails.name,
                message:messageDetails.message

            });

        }else{
            console.log("error triggering pusher");
        }

    })
})

app.get('/', (req,res) => res.status(200).send('Hello World') )

app.get('/messages/sync', (req,res) => {
    Messages.find((err,data) => {
        if(err){
            res.status(500).send(err);
        }
        else{
            res.status(200).send(data);
        }
    })
})

app.get('/room/sync', (req,res) => {
    Rooms.find((err,data) => {
        if(err){
            res.status(500).send(err);
        }
        else{
            res.status(200).send(data);
        }
    })
})

app.post('/messages/new', (req,res) => {
    const dbMessage = req.body;
    Messages.create(dbMessage, (err, data) => {
        if(err){
            res.status(500).send(err);
        }
        else{
            res.status(201).send(data);
        }
    })
})

app.post('/room/new', (req,res) => {
    const dbMessage = req.body;
    Rooms.create(dbMessage, (err, data) => {
        if(err){
            res.status(500).send(err);
        }
        else{
            res.status(201).send(data);
        }
    })
})

app.listen(PORT, () => console.log(`Server running on port ${PORT}`))