import React, { useEffect, useState } from 'react';
import Sidebar from "./Sidebar";
import Chat from "./Chat";
import axios from './axios'
import './Body.css';

export default function Body() {

  const [messages, setMessages] = useState([]);
  const [rooms, setRooms] = useState([]);
  useEffect(() => {
    axios.get('/messages/sync')
    .then(response => {
    setMessages(response.data)
    })

    axios.get('/room/sync')
    .then(response => {
      console.log(response.data);
      setRooms(response.data)
    })
  },[]);
  return (
    <div className='appBody'>
            <Sidebar rooms={rooms}> </Sidebar>
            <Chat messages={messages}> </Chat>   
    </div>
  )
}
