import React, {useState, useEffect}  from 'react'
import "./Chat.css"
import { Avatar, IconButton } from "@material-ui/core"
import MoreVertIcon from '@mui/icons-material/MoreVert';
import SearchIcon from '@mui/icons-material/Search';
import AttachFileIcon from '@mui/icons-material/AttachFile';
import InsertEmoticonIcon from '@mui/icons-material/InsertEmoticon';
import MicIcon from '@mui/icons-material/Mic';
import axios from './axios';

export default function Chat({messages}) {
    const [input, setInput] = useState("")
    const [seed, setSeed] = useState("")
    useEffect( () => { 
        setSeed(Math.floor (Math.random()*5000))
       },[])

    const sendMessage = async (e) => {
        e.preventDefault();
        await axios.post('/messages/new',
        {
            message: input,
            name: "abhikhya ashi",
            timestamp: "test time",
            recieved: false,
        }
    )
        setInput('');
    }

    return (
        <div className="chat">
            <div className="chatHeader">
                <Avatar src={`https://avatars.dicebear.com/api/human/${seed}.svg`} />
                <div className="chatHeaderInfo">
                    <h2 className = "RoomName"> Room Name</h2>
                    <p className="Last seen at ..."> Last seen at ...</p>
                </div>
                <div className="chatHeaderRight"> 
                    <IconButton> <SearchIcon /> </IconButton>
                     <IconButton> <AttachFileIcon /> </IconButton>
                    <IconButton> <MoreVertIcon />  </IconButton>
                    
                </div>
            </div>
            <div className="chatBody"> <br></br>
            {messages.map(message => (
                <p className= "chatMsg">  
                    <span className = "chatName">{message.name}</span> <br></br>{message.message}
                    <span className="chatDate"> 12:27am </span>
                </p> 
            ))}
                  
                
                           
            </div>
            <div className="chatFooter"> 
            <InsertEmoticonIcon/>
            <form>
                <input value={input} onChange={(e) => 
                    setInput(e.target.value)}
                     type="text" placeholder='Type a message'/>
                <button type="submit" onClick={sendMessage}>Send a message</button>
            </form>
            <MicIcon/>
            </div>

        </div>
    )
}
