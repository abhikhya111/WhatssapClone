import React, { useEffect, useState } from "react"
import "./Sidebar.css"
import { Avatar, IconButton } from "@material-ui/core"
import ChatIcon from '@mui/icons-material/Chat';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import SearchIcon from '@mui/icons-material/Search';
import SidebarChat from "./SidebarChat";
import db from './firebase';
import axios from './axios';


function Sidebar() {
    const [rooms, setRooms] = useState([]);
    useEffect(() => {
        db.collection("rooms").onSnapshot((snapshot) =>
            setRooms(
                snapshot.docs.map((doc) => ({
                    id: doc.id,
                    data: doc.data()
                    
                }))
            )
        );
    },[])
    return (
        <div className="sidebar" >
            <div className="sidebarHeader">
                <Avatar />
                <div className="sidebarRight">
                    <IconButton> <ChatIcon /> </IconButton>
                    <IconButton> <MoreVertIcon />  </IconButton>
                    <IconButton> <SearchIcon /> </IconButton>

                </div>
            </div>
            <div className="sidebarSearch">
                <div className="sidebarSearchContainer">
                <SearchIcon /> 
                <input type = "text" placeholder="start or search a new chat"/>

                </div>             
            </div>
            <div className="sidebarChat">
                <SidebarChat> </SidebarChat>
                <SidebarChat> </SidebarChat>
                <SidebarChat> </SidebarChat>
                <SidebarChat> </SidebarChat>
                <SidebarChat> </SidebarChat>
            </div>
            {/* <div className="SidebarChatsHeader">
                <SidebarChatsHeader> </SidebarChatsHeader>
            </div> */}
        </div>
    )
}

export default Sidebar