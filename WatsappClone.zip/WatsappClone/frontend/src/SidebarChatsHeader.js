import { React } from 'react'
import "./SidebarChat.css"
import { Avatar, IconButton } from "@material-ui/core"
import ChatIcon from '@mui/icons-material/Chat';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import SearchIcon from '@mui/icons-material/Search';


export default function sidebarChatsHeader() {

    return (
        <div className='leftHeader'>
            <Avatar />
            <h2 className="RoomName"> Room Name</h2>
        
            
            <div className='rightHeader'>
                <IconButton> <ChatIcon /> </IconButton>
                <IconButton> <MoreVertIcon />  </IconButton>
                <IconButton> <SearchIcon /> </IconButton>
            </div>
        </div>
    )
}
