import React from "react";
import "./Navbar.css"
import {Link} from "react-router-dom"

const Navbar = () => {
    return (
        <div>
            <ul>
                <li><a className="active" href="#home">
                    <Link to = "home" >                    
                    </Link></a></li>
                <li><a href="#news">
                    <Link to = "news"> 
                    </Link>
                    </a></li>
                <li><a href="#contact">Contact</a></li>
                <li><a href="#about">About</a></li>
            </ul>
        </div>

    )
}
export default Navbar