import React from 'react';
import SidebarChat from './SidebarChat';

export default function Body2() {
  return (
    <div><SidebarChat/></div>
  )
}
