import {React, useEffect, useState} from 'react'
import "./SidebarChat.css"
import { Avatar } from "@material-ui/core"

export default function SidebarChat({id, name}) {
    const [seed, setSeed] = useState("")
    useEffect( () => { 
        setSeed(Math.floor (Math.random()*5000))
       },[])

  return (
    <div className="SidebarChat">
    <Avatar src={`https://avatars.dicebear.com/api/human/${seed}.svg`}/>
    <div className="SidebarChatInfo">
        <h2 className = "RoomName"> Room Name</h2>
        <p className="LastMsg"> Last msg...</p>
    </div>
   
    </div>
    
  )
}
