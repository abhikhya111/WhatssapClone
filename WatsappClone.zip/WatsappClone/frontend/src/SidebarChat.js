import {React, useEffect, useState} from 'react'
import "./SidebarChat.css"
import { Avatar } from "@material-ui/core"
import axios from './axios'

export default function SidebarChat({rooms}) {
    const [seed, setSeed] = useState("")
    useEffect( () => { 
        setSeed(Math.floor (Math.random()*5000))
       },[])

       const addNewChat = async () => {
         const roomName = prompt('Please enter name for Chat Room');
         if(roomName){
          await axios.post('/room/new',
          {
              name: roomName,
              
          }
      )
         }
         window.location.reload();

       }
  return (
    <>
    
    <div className='addNewChat' onClick={addNewChat}>
      <h2>Add New Chat</h2>
    </div>
    {rooms.map(room => (
                <div className="SidebarChat">
                <Avatar src={`https://avatars.dicebear.com/api/human/${seed}.svg`}/>
                <div className="SidebarChatInfo">
                    <h2 className = "RoomName">{room.name}</h2>
                    <p className="LastMsg"> Last msg...</p>
                </div>
               
                </div>
            ))}
    </>
    
  )
}
