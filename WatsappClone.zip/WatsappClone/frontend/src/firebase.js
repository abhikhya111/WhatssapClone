import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import 'firebase/compat/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyD-XW4qi9AGoVHGpx8JO7HE6AIUaE6d_oU",
  authDomain: "bustling-folio-343006.firebaseapp.com",
  projectId: "bustling-folio-343006",
  storageBucket: "bustling-folio-343006.appspot.com",
  messagingSenderId: "158572249483",
  appId: "1:158572249483:web:dff9ee85f552faaef2af8e",
  measurementId: "G-CZD5EYXEHF"
};

// Use this to initialize the firebase App
const firebaseApp = firebase.initializeApp(firebaseConfig);

// Use these for db & auth
const db = firebaseApp.firestore();
// const auth = firebase.auth();

export default db;