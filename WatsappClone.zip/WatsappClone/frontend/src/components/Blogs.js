import react from "react"

function Blogs () {
    return (
        <h1> Blogs </h1>
    )
}

export default Blogs