import { Button } from "bootstrap"
import React from "react"

class Home extends React.Component {
    constructor(props){
        super(props)
        this.state = {myFavouriteColor : "Red" }
    }
    shouldComponentUpdate() {
        return true
    }
    changeColor = () => { this.setState({myFavouriteColor : "Blue"})}
        render() {
        return (
            <>
            <h1> { this.state.myFavouriteColor } </h1>
            <button onClick = {this.changeColor}>Change Color </button>
            </>          
        )
    }
    }
   

export default Home